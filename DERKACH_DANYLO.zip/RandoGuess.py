import random
import os
import sys
import webbrowser

def menu():
    logo = """         _nnnn_                      
        dGGGGMMb     ,''''''''''''''''.
       @p~qp~~qMb    | RandoGuess 1.0 |
       M|@||@) M|   _;................'
       @,----.JM| -'
      JS^\__/  qKL
     dZP        qKRb
    dZP          qKKb
   fZP            SMMb
   HZM            MMMM
   FqM            MMMM
 __| ".        |\dS"qML
 |    `.       | `' \Zq
_)      \.___.,|     .'
\____   )MMMMMM|   .'
     `-'       `--' hjm"""
    menu_text = "\nSelect option:\n \n[1] Start game\n[2] Author\n[3] Documentation\n[4] Exit"
    os.system("cls")
    print(logo)
    print(menu_text)

    option = int(input("\n>>> "))
    return option



def game():
    number = random.randint(1, 100)
    print("\nWylosowana jest liczba od 1 do 100. Sprobuj zgadnac ta liczbe")

    i = 0
    while True:
        i+=1
        try:
            print("\n╔══Podaj liczbe (1 - 100)")
            user_number = int(input("╚════> "))

        except:
            print("\n[!] Prosze podac liczbe od 1 do 100!")
            continue
        

        if user_number > 100 or user_number < 1:
            print("Wpisales nie prawidlowa liczbe.")

        elif user_number > number:
            print("[*] Twoja liczba wieksza od wylosowanej")

        elif user_number < number:
            print("[*] Twoja liczba mniejsza od wylosowanej")

        elif user_number == number:
            print("\n[*] To jest ta liczba!")
            print(f"Ilość prób: {i}")
            repeat = input("\n \n[?] Czy chcesz zagrać jeszcze raz?\n---> ")

            return repeat

while True:
    select = menu()

    match (select):
        case 1:
            while True:
                repeat = game()
                if repeat == "Tak" or repeat == "tak":
                    continue
                else:
                    break
        case 2:
            a = input("\nAuthor: Danylo Derkach\nNumer w dzienniku: 6\n \n \n© Copyright 2023, Danylo Derkach. All rights reserved\n \nNacisnij 'Enter' by kontynuowac#")
        case 3:
            webbrowser.open("https://drive.google.com/file/d/14gXZV7H7kXv1BGvFE1P_s_zrzWhCxvSD/view?usp=drivesdk", new=1)
        case 4:
            sys.exit()